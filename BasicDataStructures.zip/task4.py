#4th program
print('123.456')
print(int(((float('123.456'))*10)%10))
